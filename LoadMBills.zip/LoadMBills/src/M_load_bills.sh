#!/bin/bash

echo "M_load_bills starts" 
date
echo "..."

NLS_LANG=AMERICAN_AMERICA.WE8ISO8859P1


# sqlplus system/oracle @USER_CREATE_USER.sql
# sqlplus system/oracle @USER_USER.sql
# sqlplus XYZ/oracle @USER_CREATE_TABLES.plsql
# sqlplus XYZ/oracle @USER_CREATE_TABLES.sql
# sqlplus system/oracle @USER_RIGHTS.sql


# sqlplus SYS/oracle@XEPDB1 @M_CREATE_USER_PETROL.sql

sqlplus PETROL/oracle@XEPDB1 @M_DROP_TABLES.sql
sqlplus PETROL/oracle@XEPDB1 @M_CREATE_TABLES_AND_SOME_INSERTS.sql

for FILE_NAME in `ls ../data/bill_csv*.csv`
do
   export BASE_NAME=`basename $FILE_NAME`
   export JUST_NAME=`echo $BASE_NAME | sed -e 's/\..*//'`
   echo $FILE_NAME
   echo $BASE_NAME
   echo $JUST_NAME

#sed -e 's/"//g' $FILE_NAME | sed -e 's/ ;/;/' | sed -e 's/,/./g' | dos2unix >../data/BILL_ONE_FILE.csv

#sqlldr PETROL/oracle@XEPDB1 data=../data/BILL_ONE_FILE.csv control=M_bill_staging.ldr log=../log/$JUST_NAME.log bad=../log/$JUST_NAME.bad errors=20

sqlldr PETROL/oracle@XEPDB1 data=../data/$JUST_NAME.csv control=M_bill_staging.ldr log=../log/$JUST_NAME.log bad=../log/$JUST_NAME.bad skip=1 errors=20

sqlplus PETROL/oracle@XEPDB1 <<!
      INSERT INTO FACT_BILL 
      SELECT CUSTNAME,
	      EXTRACT (YEAR FROM billDatetime) AS SUM_YY,  
	      EXTRACT (MONTH FROM billDatetime) AS SUM_MM,
	      sum(BILLAMOUNT) AS SUM_BILLAMOUNT
      FROM BILL b 
      GROUP BY CUSTNAME,
	      EXTRACT (YEAR FROM billDatetime),  
	      EXTRACT (MONTH FROM billDatetime);
!
done

# Nachdem alle Bills gelesen wurden, 
#   wird die FACT_PETROL geladen und berechnet
sqlplus PETROL/oracle@XEPDB1 <<!
      INSERT INTO FACT_PETROL
      SELECT p.stationId,
	      EXTRACT (YEAR FROM b.billDatetime) AS SUM_YY, 
	      SUM(b.BILLAMOUNT) AS SUM_BILLAMOUNT
      FROM PATROLSTATIONES p LEFT OUTER JOIN BILL b
      ON p.stationId = b.petrolStation
      GROUP BY p.stationId, EXTRACT (YEAR FROM b.billDatetime);
!

echo "M_load_bills ends" 
date
echo "..."