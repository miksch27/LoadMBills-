
create table bill (
	billId NUMBER(9,0) NOT NULL,
	PETROLSTATION NUMBER(9,0),
	custName VARCHAR(14),
	letter1 VARCHAR(5),
	email VARCHAR(50),
	address VARCHAR(50),
	billAmount DECIMAL(5,2),
	billDatetime timestamp DEFAULT CURRENT_TIMESTAMP
);

create table FACT_petrol (
	petrolStation NUMBER(9,0) NOT NULL,
	SUM_YY decimal(5,0),
	SUM_billAmount DECIMAL(15,2)
);

create table FACT_bill (
	custName VARCHAR(14),
	SUM_YY decimal(5,0),
	SUM_MM decimal(2,0),
	SUM_billAmount DECIMAL(15,2)
);

create table patrolStationes (
	stationId NUMBER(9,0),
	geometricDistribution VARCHAR(50),
	realLatitude VARCHAR(50),
	realLongitude VARCHAR(50),
	energieStatus NUMBER,
	lastOperation DATE,
	truckGasolineVolume VARCHAR(50),
	carPatrolVolume DECIMAL(7,2)
);


ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD';
ALTER SESSION SET NLS_TIMESTAMP_FORMAT  = 'YYYY-MM-DD HH24:MI:SS';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS=',.';

/* SELECT * FROM  NLS_DATABASE_PARAMETERS; */

insert into bill (billId, petrolStation, custName, letter1, email, address, billAmount,BILLDATETIME) values (1, 98, 'Rahman', 'R', 'rfiggins0@cisco.com', '3 Ridgeway Lane', 27.49, '2022-04-03 17:05:20');
insert into bill (billId, petrolStation, custName, letter1, email, address, billAmount, billDatetime) values (2, 91, 'Predic', 'P', 'ismyth1@walmart.com', '81277 Hoard Trail', 52.99, '2021-05-24 18:31:58');
insert into bill (billId, petrolStation, custName, letter1, email, address, billAmount, billDatetime) values (3, 98, 'Pathak', 'P', 'asmithen2@abc.net.au', '117 Stoughton Place', 95.45, '2021-09-12 07:10:06');
insert into bill (billId, petrolStation, custName, letter1, email, address, billAmount, billDatetime) values (4, null, 'Pathak', 'P', 'ccarnegie3@scientificamerican.com', '85144 Golf View Avenue', 71.44, '2021-09-05 02:55:04');
insert into bill (billId, petrolStation, custName, letter1, email, address, billAmount, billDatetime) values (5, 90, 'Galic', 'G', 'dviste4@wikia.com', '474 Eggendart Parkway', 19.49, '2021-11-12 07:27:39');
insert into bill (billId, petrolStation, custName, letter1, email, address, billAmount, billDatetime) values (6, 74, 'Rahman', 'R', 'eclifforth5@nationalgeographic.com', '75366 Stephen Parkway', 59.18, '2021-09-01 21:40:18');
insert into bill (billId, petrolStation, custName, letter1, email, address, billAmount, billDatetime) values (7, 89, 'Zhuta', 'Z', 'gdelafeld6@bbc.co.uk', '134 Northridge Circle', 57.79, '2021-06-13 08:23:55');
insert into bill (billId, petrolStation, custName, letter1, email, address, billAmount, billDatetime) values (8, 50, 'Predic', 'P', 'gnichols7@gizmodo.com', '97944 Talisman Parkway', 91.83, '2021-07-01 09:27:04');
insert into bill (billId, petrolStation, custName, letter1, email, address, billAmount, billDatetime) values (9, 70, 'Galic', 'G', 'kcreany8@flickr.com', '589 Meadow Ridge Pass', 30.57, '2021-07-08 05:40:17');
insert into bill (billId, petrolStation, custName, letter1, email, address, billAmount, billDatetime) values (10, 19, 'Pathak', 'P', 'wdurnin9@bbc.co.uk', '6261 Victoria Way', 52.22, '2021-02-17 13:12:10');


ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD';
ALTER SESSION SET NLS_TIMESTAMP_FORMAT  = 'YYYY-MM-DD HH24:MI:SS';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS=',.';

/* SELECT * FROM  NLS_DATABASE_PARAMETERS; */
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (1, 1, 41.91583, 21.53056, 3, '2022-01-08', 0.7066527849, 6620.6);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (2, 2, 23.084827, 113.290609, 5, '2021-06-25', 1.3714512078, 397.97);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (3, 2, 28.642843, 111.161288, 1, '2021-09-12', 0.5356454937, 8810.89);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (4, 4, -6.7685746, 39.2134078, 3, '2021-07-24', 0.2765230152, 656.92);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (5, 7, 35.069045, -80.678518, 5, '2021-12-24', 0.071233516, 6949.84);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (6, 1, 39.9483942, -8.143466, 5, '2021-08-08', 0.1906551327, 1645.61);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (7, 1, 46.6313635, 38.6705832, 1, '2021-04-22', 0.5503417028, 2501.49);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (8, 2, -8.6573819, 121.0793705, 4, '2021-06-02', 0.2555221259, 4360.06);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (9, 1, 31.30275, 121.389084, 4, '2021-09-20', 0.0703131337, 8486.84);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (10, 2, 11.0181098, 124.5298181, 5, '2021-12-21', 0.2889386752, 4079.36);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (11, 2, 49.23335, -102.1676, 1, '2021-06-02', 0.780499759, 3523.8);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (12, 3, 8.7686886, -12.7853522, 4, '2021-06-26', 0.0147375561, 4697.45);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (13, 1, -34.7089038, -58.6427861, 1, '2021-08-10', 0.1477538464, 3618.3);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (14, 2, 59.9588359, 10.9167426, 5, '2022-03-12', 1.7899575672, 1741.95);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (15, 1, 23.6192598, -75.9695465, 1, '2021-08-19', 0.2963673355, 5566.42);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (16, 1, -7.099977, 106.888644, 4, '2021-11-12', 1.3751385643, 8754.25);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (17, 1, 39.1168675, -9.2011356, 5, '2021-10-30', 0.9957626751, 5705.5);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (18, 1, 42.3416847, 69.590101, 2, '2022-03-03', 0.4997806755, 367.5);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (19, 1, -11.72447, -75.773888, 4, '2022-02-09', 0.168164008, 4407.55);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (20, 1, 49.9521295, 22.4357438, 2, '2021-08-27', 0.4831792882, 3378.91);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (21, 3, 5.2711769, -3.5939254, 2, '2021-08-16', 1.0916343479, 1703.37);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (22, 2, 4.398278, -74.828718, 3, '2021-07-29', 0.5463508708, 4567.62);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (23, 1, 31.784791, 119.320063, 1, '2022-02-18', 0.069210868, 231.64);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (24, 2, -10.0776, 120.7569, 2, '2021-12-03', 0.0373393004, 5471.33);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (25, 1, 24.4670098, 118.0855763, 1, '2021-11-20', 0.5227389127, 2098.56);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (26, 1, 44.6773413, 20.4439853, 3, '2022-03-28', 1.6995116328, 7357.62);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (27, 1, 19.7206, 110.460225, 2, '2022-03-16', 0.0326985208, 2729.35);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (28, 1, 13.6119882, 99.6118667, 5, '2021-05-22', 0.6436000725, 3490.06);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (29, 3, 27.2711, 116.580186, 5, '2022-02-10', 1.8435000881, 1216.51);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (30, 3, 38.5261686, 141.0953438, 2, '2022-03-26', 0.4775589342, 8801.89);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (31, 1, -6.7204, 111.0994, 1, '2022-02-12', 0.1439334487, 1419.53);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (32, 2, 58.3736347, 12.3272689, 3, '2021-06-17', 0.7859494252, 3897.62);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (33, 3, 43.1298714, 45.5357156, 1, '2021-05-25', 0.0074938529, 5630.82);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (34, 3, 38.1230866, 140.0547688, 2, '2021-07-02', 0.3374824456, 7228.38);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (35, 2, 41.664757, 123.344062, 3, '2021-11-25', 0.1471830858, 1884.11);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (36, 3, 57.7470467, 14.1650902, 5, '2021-10-24', 1.1389813655, 9694.29);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (37, 1, 25.941937, 117.365052, 5, '2021-08-24', 1.7083527991, 9234.8);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (38, 4, -3.3200228, 114.9991464, 4, '2021-08-15', 0.3967414763, 4292.13);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (39, 2, 34.477513, 107.148314, 3, '2021-11-18', 0.2568664247, 9777.6);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (40, 2, 7.32688, 124.297205, 4, '2022-02-19', 0.6444193422, 8904.09);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (41, 3, 29.020827, 110.637506, 3, '2021-12-17', 0.6891523043, 5382.54);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (42, 1, 11.2658847, 7.6480296, 5, '2021-04-23', 0.8509617098, 6158.71);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (43, 1, -22.5306158, -52.1708052, 5, '2021-07-12', 0.6433917068, 2667.77);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (44, 1, 23.131797, 113.407143, 5, '2021-08-02', 0.0060745645, 9288.78);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (45, 1, 4.956167, -76.607349, 1, '2022-01-04', 0.1265963837, 1967.75);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (46, 1, 50.5032152, 14.2856356, 3, '2021-09-04', 0.3738914353, 9340.07);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (47, 4, 19.188296, 108.799374, 2, '2021-04-07', 0.3970670283, 1537.21);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (48, 1, 39.8592119, 20.0271001, 5, '2022-03-23', 0.3135663506, 5178.02);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (49, 2, 13.415029, 34.6248039, 2, '2021-06-18', 0.4209805188, 7380.43);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (60, 1, 54.3924957, 48.577155, 1, '2021-10-20', 0.613211879, 4492.08);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (61, 2, 51.1347637, 133.0393804, 5, '2021-10-11', 0.0687014108, 7872.62);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (62, 1, 36.4045915, 139.2613339, 5, '2022-01-14', 0.3654093114, 1908.78);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (63, 2, -31.4149049, -64.1467066, 2, '2021-12-26', 0.1108236915, 5257.21);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (64, 6, 59.330173, 18.0551861, 2, '2021-08-27', 0.3068019031, 7867.09);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (65, 1, 16.961392, 102.2728739, 3, '2021-12-21', 0.1188322996, 3668.86);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (66, 3, 32.280756, 105.513062, 5, '2021-10-01', 0.3064397403, 6681.23);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (67, 2, 27.3115158, 30.9713333, 2, '2021-04-18', 0.6179062266, 7885.07);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (68, 2, 1.0565562, 124.4946697, 5, '2022-01-03', 0.1451107091, 5587.04);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (69, 1, 42.1142239, -84.2494229, 2, '2021-12-28', 0.911869505, 5720.26);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (70, 1, 22.0899425, 104.7695962, 1, '2021-10-27', 0.3743606436, 42.91);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (71, 1, 46.16667, 112.95, 5, '2022-01-01', 0.7331369369, 9508.12);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (72, 1, 51.2217758, 19.877027, 4, '2022-03-12', 0.6189712118, 7976.31);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (73, 1, 27.330904, 117.044081, 3, '2021-11-10', 0.2084732348, 899.78);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (74, 1, 49.880883, 19.217373, 4, '2021-09-01', 0.2029892464, 7592.3);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (75, 1, 43.258497, 117.54141, 5, '2021-04-26', 0.8725388784, 2650.42);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (76, 2, 30.96187, 113.378132, 3, '2021-05-01', 0.3333389887, 5616.78);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (77, 2, 45.2557594, 41.8390104, 3, '2021-08-18', 0.3927626888, 2597.72);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (78, 4, 41.09028, 128.29333, 1, '2022-01-22', 0.1565998906, 512.57);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (79, 2, 35.981548, 139.7460429, 3, '2021-06-19', 0.1215223111, 546.52);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (80, 4, 52.6325793, 4.7239896, 1, '2021-04-15', 0.1490582456, 7237.22);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (81, 1, -1.2664363, 132.0484904, 2, '2022-01-30', 0.2450287531, 3471.75);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (82, 1, 55.5807611, 37.7673912, 5, '2022-03-06', 1.4276233162, 4285.95);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (83, 3, -6.2306088, -77.9554253, 1, '2021-11-25', 1.1668154968, 3002.78);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (84, 3, 50.9115477, 14.6182476, 5, '2022-03-14', 0.0228615117, 9482.93);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (85, 3, 27.236635, 108.912375, 4, '2021-08-15', 0.9832326487, 8841.12);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (86, 2, 0.3642599, 108.954903, 3, '2021-08-26', 0.2195914395, 6609.92);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (87, 1, 10.6095479, 122.955299, 5, '2022-03-15', 0.1637001296, 2374.03);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (88, 3, -8.3979403, 115.4318914, 2, '2021-12-13', 0.0026203757, 9525.82);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (89, 1, 25.876232, 105.114764, 5, '2022-01-01', 0.0627499438, 8929.27);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (90, 1, 42.319384, -85.1872878, 3, '2021-05-08', 0.2232665383, 8501.31);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (91, 2, 49.7880079, 14.293561, 2, '2021-12-17', 0.1814424502, 9792.34);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (92, 3, 46.6666667, 93.25, 1, '2021-12-01', 0.2817214912, 5423.68);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (93, 1, 33.8462304, 35.9019775, 1, '2021-04-18', 2.2513273562, 8817.41);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (94, 7, 30.73892, 92.174161, 5, '2021-03-31', 0.3824328862, 6445.31);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (95, 1, 58.3736347, 12.3272689, 2, '2022-03-05', 0.1718192405, 9600.69);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (96, 1, 43.4945737, 5.8978018, 4, '2022-01-16', 0.0025354674, 4159.72);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (97, 1, -24.0088421, -46.4124616, 2, '2021-09-13', 0.7107164822, 5121.42);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (98, 2, 49.5970348, 16.041166, 1, '2021-08-22', 0.204962047, 3880.22);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (99, 2, 19.482042, -99.1985584, 3, '2021-09-01', 0.3310806787, 7461.08);
insert into patrolStationes (stationId, geometricDistribution, realLatitude, realLongitude, energieStatus, lastOperation, truckGasolineVolume, carPatrolVolume) values (100, 1, -34.5500929, -58.4984714, 2, '2022-02-18', 0.6654191095, 9741.86);
exit;